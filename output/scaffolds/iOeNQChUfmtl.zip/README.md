# test-scaffold-project

Landing page website portofolio dengan React + Vite + Tailwind CSS + Framer Motion.